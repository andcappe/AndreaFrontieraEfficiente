file = 'cryptoAndrea.xlsx'
benc='AZNAX'
T= readtable(file);


A = T.Properties.VariableNames(1,2:end);
A(1,size(A,2)+1)=cellstr(upper(benc));

P = table2array(T(2:end,2:end));
D = datenum(table2array(T(2:end,1)));