%%
clear all; clc;
gg=250;
file='titoli.xlsx';
freq = 'd';
        benc = 'aznax';
T= readtable(file);
T=(table2cell(T))';

A = T(1,:);
A(1,size(A,2)+1)=cellstr(upper(benc));



%Desc = T(2,:);

[rA,cA]= size(A);
%%
for i=1:cA

stock = get_yahoo_stockdata(A(1,i));

database{1,i}=stock;
Desc = stock.ticker;
Date = stock.timeStamp;
Open = stock.openPrice;
High = stock.highPrice;
Low = stock.lowPrice;
Close = stock.closePrice;
Volume = stock.volume;

StockData_TimeTable = timetable(Date,Open,High,Low,Close,Volume);
%StockData_TimeTable = retime(StockData_TimeTable,'daily','previous');
if any(any(ismissing(StockData_TimeTable)))==true
    StockData_TimeTable = fillmissing(StockData_TimeTable,'nearest');
end
%%TT=timetable2table(StockData_TimeTable)

P(:,i) = StockData_TimeTable.Close(end-gg:end,1);
D(:,i) = floor(datenum(StockData_TimeTable.Date(end-gg:end,1)));



clear stock ;
clear ans;
end

 %%

        %ii = any(isnan(P),2);
       % D(ii) = [];
       % P(ii,:) = [];
if any(any(ismissing(P)))==true
    P = fillmissing(P,'nearest');
end
filename='MatriceAssetClass.mat';
save(filename);

%str = regexprep( A,('[\^.MI]') , '');
%T = array2table(P,'VariableNames',str);
%TD = table(datestr(D(:,1)),'VariableNames', {'DATE'});
%T=[TD T];
%writetable(T,' PrezziExcel.xlsx');