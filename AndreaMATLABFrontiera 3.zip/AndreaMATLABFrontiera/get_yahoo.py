#pip install pandas-datareader
from pandas_datareader import data
da_zm= data.get_data_yahoo("ZM")
df_zm