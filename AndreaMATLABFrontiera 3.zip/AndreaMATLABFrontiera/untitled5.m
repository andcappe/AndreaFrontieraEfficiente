%%
 for i=1:size(data,1)
if data(i,1)> lead(i,1) & Stocastico{1,j}(i,4)> 0.20
        signal(i,1)=1;
elseif data(i,1)< lead(i,1) & Stocastico{1,j}(i,4)< 0.80
        signal(i,1)=-1;
else
    signal(i,1)=0;
end
 end
 
 %%
n=200
figure(1)
s=mean(Stocastico{1,15},2)
si=1/s
si=si'
subplot(3,1,1)
plot(P(1:n,15))
subplot(3,1,2)
%plot(Stocastico{1,15}(1:n,1:4))
plot(s)
subplot(3,1,3)
plot(si(1:n,1))