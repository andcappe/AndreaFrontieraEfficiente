%%
clear all; clc;
%gg=250;
%file='Tit.xlsx'; %'titoli.xlsx'

[A,D,P] = scaDati();

%%
gg=250;
r=0; % 1 Porta a 100 la partenza del rendimento altrimenti e' 0
[fD, rfP]=dayReturns(gg,r,A,D,P);

%%
gg=60;
NumPortf=20;

[mrsk,mret, crsk, cret, prsk, pret, pwgt, swgt, qwgt, Assetlist,q,p] = ffSharpe(gg,NumPortf,A,P);

%%
figure(3);
numT=size(P);
mymap = [0.2 0.4 0.1
    1 1 1
    1 0 0];

corr(P);
imagesc(ans); % Display correlation matrix as an image
colormap(spring);
colorbar ('southoutside'); 
set(gca, 'XTick', 1:numT(2)); % center x-axis ticks on bins
set(gca, 'YTick', 1:numT(2)); % center y-axis ticks on bins
set(gca, 'XTickLabel', A); % set x-axis labels
set(gca, 'YTickLabel', A); % set y-axis labels
title('Matrice di correlazione', 'FontSize', 10); % set title
xtickangle(90);

%% Portafoglio desiderato in funzione del proprio profilo di rischio.
Prof=14;
qwgt = q.estimateFrontier(NumPortf);
Portfolio=qwgt(:,Prof);

Blotter = dataset({100*Portfolio(Portfolio > 0),'Weight'}, 'obsnames', Assetlist(Portfolio > 0));
vetSum=ones(size(qwgt(:,Prof)));

Azioni=qwgt'*vetSum;

fprintf('Portfolio selezionato');
disp(Blotter);
%% Azioni in portafoglio da detenere in funzione del rischio desiderato
Azioni=qwgt'*vetSum;
requestIDs = 'ProfiloID';
for k = 1 : 20
    requestID(k,:) = [requestIDs '_' num2str(k,'%02d')];        % Character Array
    end
Profili=cellstr(requestID);
Plotter = dataset({Azioni,'Azionario'}, 'obsnames', Profili);
fprintf('Profili');
disp(Plotter);


%%
[MedieMobili MedieCentrate Stocastico Oscillatore relstr] = indic(8,A,D,P);

%%
gg=240;
mB=8; % media mobile multipli di 8
mL=40;% media mobile multipli di 8

PanelPrezzi(gg,A,D,P,MedieMobili,mB,mL);
%%
gg=240;
r=0; %Indicare 100 come numero indice o zero
[rfP] = PanelRendimenti(gg,r,A,D,P);

%%
gg=100;      % Giorni per la rilevazione
indice=2;    % Indicare 1.MedieCentrate 2.Stocastico 3.Oscillatore 4.RSI 
r=1;
mB=8;
mL=64;
[rfP] = PanelIndicatori(gg,indice,r,A,D,P, MedieCentrate, Stocastico, Oscillatore, relstr,mB,mL);


%%
gg=200;
j=25;
le=5;
la=26;
mB=9;
mL=26;
PanelFibonacci(gg,A,D,P,j,le,la,Stocastico,MedieMobili, relstr,mB,mL)
%%
slide=10
gg=150

j=8
le=5;
la=26;
tendenza=1; %1 rialzo o -1 ribasso 
forza=2; %da 0 a 2
ciclo=256 %512 o 256
battleplan=[64 32 16 8]; %Moltiplicatori di 16
l=-4; % 0 assenza ciclo -4 ciclo ordinario
m=-3; % 0 assenza ciclo -3 ciclo ordinario
s=-2  % 0 assenza ciclo -2 ciclo ordinario
xs=-1 
[cic]=cicli(gg,slide,ciclo, A,D,P,j,le,la, tendenza, forza, battleplan,l,m,s,xs)
