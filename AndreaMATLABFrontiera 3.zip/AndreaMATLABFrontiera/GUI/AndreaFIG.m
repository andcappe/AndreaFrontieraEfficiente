function varargout = AndreaFIG(varargin)
% ANDREAFIG MATLAB code for AndreaFIG.fig
%      ANDREAFIG, by itself, creates a new ANDREAFIG or raises the existing
%      singleton*.
%
%      H = ANDREAFIG returns the handle to a new ANDREAFIG or the handle to
%      the existing singleton*.
%
%      ANDREAFIG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ANDREAFIG.M with the given input arguments.
%
%      ANDREAFIG('Property','Value',...) creates a new ANDREAFIG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before AndreaFIG_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to AndreaFIG_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help AndreaFIG

% Last Modified by GUIDE v2.5 01-Mar-2021 09:40:45

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @AndreaFIG_OpeningFcn, ...
                   'gui_OutputFcn',  @AndreaFIG_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before AndreaFIG is made visible.
function AndreaFIG_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to AndreaFIG (see VARARGIN)

% Choose default command line output for AndreaFIG
movegui(gcf,'center')
dim = get(0,'ScreenSize');
width  = dim(3);
height = dim(4);
guiWidth = round(width*0.7);
guiHeight = round(height*0.8);
set(gcf,'Units','Pixels','Position',[(width-guiWidth)/2 (height-guiHeight)/2 guiWidth guiHeight])

set(handles.axes1,'Visible','off');
set(handles.axes2,'Visible','off');
set(handles.axes3,'Visible','off');


handles.output = hObject;

% Update handles structure
set(handles.axes1,'Visible','off');
set(handles.axes2,'Visible','off');
set(handles.axes3,'Visible','off');

load('data_image','image1')
load('model_image','image2')
load('correlation_image','image3')

axes(handles.axes1);
set(gca,'XTickLabel','','XTick',0)
set(gca,'YTickLabel','','YTick',0)
axes(handles.axes2);
set(gca,'XTickLabel','','XTick',0)
set(gca,'YTickLabel','','YTick',0)
axes(handles.axes3);
set(gca,'XTickLabel','','XTick',0)
set(gca,'YTickLabel','','YTick',0)

axes(handles.axes1);
image(image1);
axis off

axes(handles.axes2);
image(image2);
axis off


axes(handles.axes3);
image(image3);
axis off


guidata(hObject, handles);

% UIWAIT makes AndreaFIG wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = AndreaFIG_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cla(handles.axes1)
cla(handles.axes2)
cla(handles.axes3)

[filename, pathname] = uigetfile( ...
    {'*.xlsx', 'All xlsx-Files (*.xlsx)'; '*.xls','All xls-Files (*.xls)' ; '*.csv' , 'All csv-Files (*.csv)' ; '*.*' , 'All Files'}, 'Select Address Book');
% If "Cancel" is selected then return
if isequal([filename,pathname],[0,0])
    return
% Otherwise construct the fullfilename and Check and load the file
else
    File = fullfile(pathname,filename);
    num=xlsread(File);
 
    dataColumn=1;
    if (size(num,2)>1)
        msg=sprintf('Select the data column: \n');
        prompt= msg;
        name='';
        numlines=1;
        defaultanswer={'1'};
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        try
            dataColumn=str2num(cell2mat(answer));
        catch
            return
        end
    end
 
    if (size(num,2)==0)
        errordlg('Your selected file includes no number.', 'Error');
        return 
    else
        try
            data=num(:,dataColumn);
            plot_all(data,hObject);
            handles.metricdata.data=data;
        catch
            msg=sprintf('Selected column containts no data! \n');
            errordlg(msg); 
        end
    end    
end
guidata(hObject, handles);


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over pushbutton1.
function pushbutton1_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
