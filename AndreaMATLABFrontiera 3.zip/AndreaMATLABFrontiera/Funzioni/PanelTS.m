
function [rfP] = PanelTS(gg,A,D,P)

% Include trading costs
% We'll add the trading cost associated with the bid/ask spread.  This will
% get us closer to the actual profit we could expect.  As an exercise, you
% should extend this to account for additional trading costs and slippage
% considerations.

close all
n=size(A,2);
ng=n./2;
nP=size(P);




for k=1:ng:40;
    sA=A(:,k:k+ng-1)
    cost=0.01; % bid/ask spread
    range = {1:1:120,1:1:120};
    annualScaling = sqrt(250);
    llfun =@(x) leadlagFunM(x,P(:,k),annualScaling,cost);

    tic
    [maxSharpe,param,sh,vars] = parameterSweep(llfun,range);
    toc

  
  
  figure('NumberTitle', 'on', 'Name', 'RENDIMENTI');
  for ii=1:ng
      subplot(ng./5,5,ii);
      
                
                 [maxSH,row] = max(sh);    % max by column
[maxSH,col] = max(maxSH);
leadlagM(P(:,ii),row(col),col,annualScaling,cost)
	title(sA(1,ii))			
				
  end
end
	
  

end