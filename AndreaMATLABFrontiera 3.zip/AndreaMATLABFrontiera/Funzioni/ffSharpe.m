function [mrsk,mret, crsk, cret, prsk, pret, pwgt, swgt, qwgt, Assetlist,q,p] = ffSharpe(gg,NumPortf,A,P)

close all

%
AssetReturns=P(2:end,:)./P(1:end-1,:)-1;
[rR,cR]=size(AssetReturns(end-gg:end,1:end));
CashSerie=[100:2/252:100+2/252*(rR)]';
CashReturns=CashSerie(2:end,:)./CashSerie(1:end-1,:)-1;

mret = mean(AssetReturns(end-gg:end,end))*252;
mrsk = std(AssetReturns(end-gg:end,end))*sqrt(252);

cret = 0; %mean(CashReturns)*(252);
crsk = std(CashReturns)*sqrt(252);


Assetlist=A(1,1:end-1);

p.NumAssets = size(A, 2)-1;
p = PortfolioDemo('AssetList', A(1,1:end-1), 'RiskFreeRate', cret);
p = p.estimateAssetMoments(AssetReturns(end-gg:end,1:end-1), 'missingdata', true);
p = p.setDefaultConstraints;
pwgt = p.estimateFrontier(NumPortf);
[prsk, pret] = p.estimatePortMoments(pwgt);
prsk=prsk*sqrt(252);
pret=pret*252;

%

q = p.setBudget(0,1);

q.RiskFreeRate = cret;
qwgt = q.estimateFrontier(NumPortf);
[qrsk, qret] = q.estimatePortMoments(qwgt);
qrsk=qrsk*sqrt(252);
qret=qret*252;

p = p.setInitPort(1/p.NumAssets);
[ersk, eret] = p.estimatePortMoments(p.InitPort);
ersk=ersk*sqrt(252);
eret=eret*252;
swgt = p.maximizeSharpeRatio;
[srsk, sret] = p.estimatePortMoments(swgt);

srsk=srsk*sqrt(252);
sret=sret*252;
%%
p.AssetMean = p.AssetMean*252;
p.AssetCovar = p.AssetCovar*252;
c=0.02;
figure (2)
part1_intro_plot('Efficient Frontier with Maximum Sharpe Ratio Portfolio', ...
	{'line', prsk, pret}, ...
    {'line', qrsk, qret, [], [], 1}, ...
	{'scatter', srsk, sret, {'Sharpe'}}, ...
	{'scatter', [mrsk, crsk, ersk], [mret, c, eret], {'Benchmark', 'Cash', 'Equal'}}, ...
	{'scatter', sqrt(diag(p.AssetCovar)), p.AssetMean, p.AssetList, '.r'});
hold on
plot(srsk, sret, 'ored');
plot(qrsk, qret, 'ored');


end

