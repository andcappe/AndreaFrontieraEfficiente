function  PanelPrezzi(gg,A,D,P,MedieMobili,mB,mL)
close all

    n=size(A,2);
    ng=n./2;
 
for k=1:ng:size(P,2)
  sP=P(:,k:k+ng-1);
  sMM=MedieMobili(:,k:k+ng-1);
  sA=A(:,k:k+ng-1);
  figure('NumberTitle', 'on', 'Name', 'PREZZI e MEDIE MOBILI');
  for ii=1:ng
      subplot(ng./5,5,ii);
                plot(D(end-gg:end,1), sP(end-gg:end,ii),'LineWidth',2);figure(gcf); hold all;
                plot(D(end-gg:end,1), sMM{1,ii}(end-gg:end,mB),'LineWidth',1);figure(gcf);hold all;
                plot(D(end-gg:end,1), sMM{1,ii}(end-gg:end,mL),'LineWidth',1,'DisplayName','Oscillatore{1,1}(end-gg:end,8)','YDataSource','Oscillatore{1,1}(end-gg:end,8)');figure(gcf);hold all;
                
                datetick('x','ddmmyy','keepticks','keeplimits')
                ylim([min(sP(end-gg:end,ii))-abs(floor(min(sP(end-gg:end,ii))))*0.05 max(sP(end-gg:end,ii))+floor(max(sP(end-gg:end,ii)))*0.05])
                xlim('auto')
                grid on
                grid minor
                
                ylabel('Valori');
                xlabel('Tempo');
                h= legend('Medie Mobiili', 'Location', 'SW');
                title(sA(1,ii));
  end
end
end