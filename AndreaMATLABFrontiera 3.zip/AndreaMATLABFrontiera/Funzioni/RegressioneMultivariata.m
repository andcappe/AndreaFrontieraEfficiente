%% Regressione
%  Il modello di regressione lineare:
%  y=?0+?1x+?

%% Carico i dati dal foglio di calcolo di Excel 
% Si prepara il file ordinando in colonne le variabili da analizzare 

clc; 
clear all; 

file = 'USdata.xlsx'; 
T= readtable(file)
T.Anno=datenum(T.Anno)   %x2mdate(T.Anno);

%% Nomi variabili analizzate
VarNam = T.Properties.VariableNames % Serve solo per richiamare i nomi delle variabili
%%

plotyy(T.Anno,T.Inflazione, T.Anno,T.Disoccupazione) % Posso mettere a confronto le varie variabili cambiando dopo il termine T. la variabile che voglio analizzare.

datetick('x','mmyy')
grid on
xlabel('Anni')
ylabel('Variazioni percentuali')
h= legend({'Inflazione', 'Disoccupazione'}  , 'Location', 'SW')
title('Grafico Variabile')



%% Modelli
startime=20; % Indico i trimestri da analizzare
endtime=0; % Indico se voglio analizzare i trimestri indicati sopra da n trimestri indietro nel tempo rispetto ad oggi.
modelspec = 'Disoccupazione ~  Inflazione ' % Questa riga serve a modificare 


Dati=size(T,1)-endtime
D=T(Dati-startime:Dati,:)

% Modelli di esempio togliere il carattere % e metterlo sopra per
% analizzare i successivi modelli di esempio 
% modelspec = 'TY ~ Inflazione + Musa + Disoccupazione + GDP + MV + CrudeOil  ' 
% modelspec = 'Inflazione ~      Musa    '
% modelspec = 'Inflazione ~ Musa + Disoccupazione + GDP + MV+ CrudeOil + TY' 
% modelspec = 'Inflazione ~ TY + Musa + Disoccupazione + GDP + MV + CrudeOil  '
% modelspec = 'TY ~ Inflazione  + Disoccupazione + GDP  + CrudeOil' % Questa riga serve a modificare 

mdl = fitlm(D,modelspec) % ***,'RobustOpts','on'*** se si vogliono dati robusti all'eteroschedasticit? indicare il valore tra gli asterischi. 
plotResiduals(mdl)

%% Miglioriamo il modello
mdl1 = step(mdl,'NSteps',10)
plotResiduals(mdl)
%% Plot della regressione e dei modelli stimati
plot(D.Anno,D.Disoccupazione) % indicare dopo D. la variabile da plottare.
hold on;

ypred = predict(mdl);
ypred2= predict(mdl1)
 
hold on;
plot(D.Anno,ypred)
plot(D.Anno,ypred2)
datetick('x','ddmmyy','keepticks','keeplimits')
                    xlim('auto')
                    grid on
                    grid minor
                    ylabel('Valori')
                    xlabel('Tempo')
                    h= legend({'Regressione', 'Modello' 'Ottimizzazione'}  , 'Location', 'SW');
                    title('PREVISIONE') 
                    
                   
%% Test di Eteroschedasticit?

[T,P,df] = BPtest(mdl)