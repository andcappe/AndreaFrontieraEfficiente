function [rfP] = PanelIndicatori(gg,indice,r,A,D,P, MedieCentrate, Stocastico, Oscillatore, relstr,mB,mL)

close all
n=size(A,2);
    ng=n./2;
nP=size(P);

fP=P(nP(1)-gg:nP(1),:);
fD=D(nP(1)-gg:nP(1),1);

[fPr fPc]=size(fP);

for  i=1:fPr
    for j=1:fPc
        rfP(i,j)=   (fP(i,j)-fP(1,j))./fP(1,j);
    end
    
end
if r==1
rfP=100+100*rfP;
else
rfP=rfP;
end
for k=1:ng:size(P,2)
  srfP=P(:,k:k+ng-1);
  sMC=MedieCentrate(:,k:k+ng-1);
  sA=A(:,k:k+ng-1);
  sStoc=Stocastico(:,k:k+ng-1);
  sO=Oscillatore(:,k:k+ng-1);
  sRS=relstr(:,k:k+ng-1);
  figure('NumberTitle', 'on', 'Name', 'INDICATORI TECNICI');
  for ii=1:ng
      subplot(ng./5,5,ii);
if indice==1
                    numT=size(P);
                
                    plot(D(end-gg:end,1), srfP(end-gg:end,ii),'LineWidth',2);figure(gcf); hold all
                    plot(D(end-gg:end,1), sMC{1,ii}(end-gg:end,mB),'LineWidth',1);figure(gcf);hold all
                    plot(D(end-gg:end,1), sMC{1,ii}(end-gg:end,mL),'LineWidth',2,'DisplayName','Oscillatore{1,1}(1:end,8)','YDataSource','Oscillatore{1,1}(1:end,8)');figure(gcf);hold all

                
    
                    datetick('x','ddmmyy','keepticks','keeplimits')
                    ylim([min(srfP(end-gg:end,ii))-abs(floor(min(srfP(end-gg:end,ii))))*0.05 max(srfP(end-gg:end,ii))+floor(max(srfP(end-gg:end,ii)))*0.05])
                    xlim('auto')
                    grid on
                    grid minor
                    ylabel('Valori');
                    xlabel('Tempo');
                    h= legend('Medie Centrate' , 'Location', 'SW');
                    title(sA(1,ii)) ;
                    elseif indice==2
            
                    numT=size(P);
                
				
                    plot(D(end-gg:end,1), sStoc{1,ii}(end-gg:end,1),'LineWidth',2);figure(gcf);hold all
                    plot(D(end-gg:end,1), sStoc{1,ii}(end-gg:end,2),'LineWidth',1,'DisplayName','Oscillatore{1,1}(1:end,8)','YDataSource','Oscillatore{1,1}(1:end,8)');figure(gcf);hold all
                    plot(D(end-gg:end,1), sStoc{1,ii}(end-gg:end,3),'LineWidth',1);figure(gcf);hold all
                    plot(D(end-gg:end,1), sStoc{1,ii}(end-gg:end,4),'LineWidth',2,'DisplayName','Oscillatore{1,1}(1:end,8)','YDataSource','Oscillatore{1,1}(1:end,8)');figure(gcf);hold all

                
    
                    datetick('x','ddmmyy','keepticks','keeplimits')
                    %ylim([min(sStoc{1,ii}(end-gg:end,1:4))-abs(floor(min(sStoc{1,ii}(end-gg:end,ii))))*0.05 max(sStoc{1,ii}(end-gg:end,ii))+floor(max(sStoc{1,ii}(end-gg:end,ii)))*0.05])
                    xlim('auto')
                    grid on
                    grid minor
                    ylabel('Valori');
                    xlabel('Tempo');
                    h= legend('Stocastico' , 'Location', 'SW');
                    title(sA(1,ii)) ;
                        elseif indice == 3
            
                    numT=size(P);
                
				
                    plot(D(end-gg:end,1), sO{1,ii}(end-gg:end,8),'LineWidth',2);figure(gcf);hold all
                    plot(D(end-gg:end,1), sO{1,ii}(end-gg:end,16),'LineWidth',1,'DisplayName','Oscillatore{1,1}(1:end,8)','YDataSource','Oscillatore{1,1}(1:end,8)');figure(gcf);hold all
                    plot(D(end-gg:end,1), sO{1,ii}(end-gg:end,24),'LineWidth',1);figure(gcf);hold all
                    plot(D(end-gg:end,1), sO{1,ii}(end-gg:end,32),'LineWidth',2,'DisplayName','Oscillatore{1,1}(1:end,8)','YDataSource','Oscillatore{1,1}(1:end,8)');figure(gcf);hold all
                    
                    datetick('x','ddmmyy','keepticks','keeplimits')
                    %ylim([min(sO{1,ii}(end-gg:end,ii))-abs(floor(min(sO{1,ii}(end-gg:end,ii))))*0.05 max(sO{1,ii}(end-gg:end,ii))+floor(max(sO{1,ii}(end-gg:end,ii)))*0.05])
                    xlim('auto')
                    grid on
                    grid minor
                    ylabel('Valori');
                    xlabel('Tempo');
                    h= legend('Oscillatore', 'Location', 'SW');
                     title(sA(1,ii)) ;
                    else indice == 4
            
                    numT=size(P);
                
				
                    plot(D(end-gg:end,1), sRS{1,ii}(end-gg:end,1),'LineWidth',2);figure(gcf);hold all
                    plot(D(end-gg:end,1), sRS{1,ii}(end-gg:end,2),'LineWidth',1,'DisplayName','Oscillatore{1,1}(1:end,8)','YDataSource','Oscillatore{1,1}(1:end,8)');figure(gcf);hold all
                    plot(D(end-gg:end,1), sRS{1,ii}(end-gg:end,3),'LineWidth',1);figure(gcf);hold all
                    plot(D(end-gg:end,1), sRS{1,ii}(end-gg:end,4),'LineWidth',2,'DisplayName','Oscillatore{1,1}(1:end,8)','YDataSource','Oscillatore{1,1}(1:end,8)');figure(gcf);hold all
                    
                    datetick('x','ddmmyy','keepticks','keeplimits')
                    %ylim([min(sRS{1,ii}(end-gg:end,ii))-abs(floor(min(sRS{1,ii}(end-gg:end,ii))))*0.05 max(sRS{1,ii}(end-gg:end,ii))+floor(max(sRS{1,ii}(end-gg:end,ii)))*0.05])
                    xlim('auto')
                    grid on
                    grid minor
                    ylabel('Valori')
                    xlabel('Tempo')
                    h= legend('Rsi' , 'Location', 'SW');
                    title(sA(1,ii)) 
end
                  
end	
end




end

