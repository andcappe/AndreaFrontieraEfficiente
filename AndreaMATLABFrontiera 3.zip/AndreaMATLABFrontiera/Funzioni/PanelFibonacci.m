function  PanelFibonacci(gg,A,D,P,j,le,la,Stocastico,MedieMobili,relstr,UI,rstdev,mB,mL ROC)
close all

numT=size(P)
for i=1:numT(2)
data=P(:,i);
[lead(:,i),lag(:,i)]=movavg(P(:,i),le,la,0);
[lead2(:,i),lag2(:,i)]=movavg(P(:,i),le*2,la*4,0);



for r=2:numT(1);



m(1,i)=P(1,i);
M(1,i)=P(1,i);

levels=[0,0.236,0.382,0.5,0.618, 0.764, 1];

f1(1,i)=P(1,i);
f2(1,i)=P(1,i);
f3(1,i)=P(1,i);
f4(1,i)=P(1,i);
f5(1,i)=P(1,i);
f6(1,i)=P(1,i);
f7(1,i)=P(1,i);

liv1(1,i)=f2(1,i);
liv2(1,i)=f3(1,i);
liv3(1,i)=f4(1,i);
liv4(1,i)=f5(1,i);
trig(1,i)=P(1,i);



m(1,i)=P(1,i);
M(1,i)=P(1,i);

levels=[0,0.236,0.382,0.5,0.618, 0.764, 1];

f1(1,i)=P(1,i);
f2(1,i)=P(1,i);
f3(1,i)=P(1,i);
f4(1,i)=P(1,i);
f5(1,i)=P(1,i);
f6(1,i)=P(1,i);
f7(1,i)=P(1,i);

liv1(1,i)=f2(1,i);
liv2(1,i)=f3(1,i);
liv3(1,i)=f4(1,i);
liv4(1,i)=f5(1,i);
trig(1,i)=P(1,i);




    if P(r,i)>=M(r-1,i);        % Se il prezzo ? maggiore del massimo
        M(r,i) = P(r,i);        % Il massimo diventa il prezzo      
        m(r,i) = m(r-1,i);      % Il minimo rimane uguale a quello del dato immediatamente precedente
        
            f1(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,1);         % Vengono calcolati i livelli di Fibonacci
            f2(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,2);         % tra il livello  minimo e massimo     
            f3(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,3);
            f4(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,4);
            f5(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,5);
            f6(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,6);
            f7(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,7);
            
    elseif P(r,i)<= m(r-1,i); % Se il prezzo ? minore del minimo 
        m(r,i) = P(r,i);       % Il prezzo diventa il nuovo minimo 
        M(r,i) = M(r-1,i); % il massimo rimane quello precedente
        
            f1(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,1); % Si calcolano i livelli di Fibonacci
            f2(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,2);
            f3(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,3);
            f4(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,4);
            f5(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,5);
            f6(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,6);
            f7(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,7);
            
    else P(r,i)<M(r-1,i) & P(r,i)>m(r-1,i); % Caso in cui il prezzo sia tra minimo e massimo 
        
        if P(r-1,i)<= f3(r-1,i) & P(r,i)> f3(r-1,i); % Attraversamento livello  al rialzo
            
                M(r,i)=P(r,i); % Massimo uguale al prezzo
                
                m(r,i)=m(r-1,i); % Minimo uguale al precedente
                
             f1(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,1);
             f2(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,2);
            f3(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,3);
            f4(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,4);
            f5(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,5);
            f6(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,6);
            f7(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,7);

                
        elseif P(r-1,i) >= f6(r-1,i) & P(r,i) < f6(r-1,i); % Superamento livello  al ribasso
            m(r,i)=P(r,i); % Mimino uguale al prezzo
            M(r,i)=M(r-1,i); % Massimo rimane uguale
            f1(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,1); % Calcolo livelli
            f2(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,2);
            f3(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,3);
            f4(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,4);
            f5(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,5);
            f6(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,6);
            f7(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,7);
        else
            M(r,i)=M(r-1,i); % Nei casi residuali minimo e massimo rimangono uguali.
            m(r,i)=m(r-1,i);
            f1(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,1);
            f2(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,2);
            f3(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,3);
            f4(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,4);
            f5(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,5);
            f6(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,6);
            f7(r,i)=M(r,i)-(M(r,i)-m(r,i))*levels(1,7);
           
   

 
            
        end
         
    end
    if P(r,i)>=lead(r-1,i) ; % Il prezzo ? sopra la media e siamo al rialzo
        trig(r,i)=m(r,i); % Partono i livelli dal minimo
        
        liv1(r,i)=trig(r,i)+(M(r,i)-m(r,i))*0.618;
        liv2(r,i)=trig(r,i)+(M(r,i)-m(r,i))*1;
        liv3(r,i)=trig(r,i)+(M(r,i)-m(r,i))*1.236;
        liv4(r,i)=trig(r,i)+(M(r,i)-m(r,i))*1.382;
        
    else P(r,i)<lead(r-1,i) ; % Il prezzo ? sotto la media e siamo al ribasso
       
        
       trig(r,i)=M(r,i);% Partono i livelli dal massimo
        
        liv1(r,i)=trig(r,i)-(M(r,i)-m(r,i))*0.618;
        liv2(r,i)=trig(r,i)-(M(r,i)-m(r,i))*1;
        liv3(r,i)=trig(r,i)-(M(r,i)-m(r,i))*1.382;
        liv4(r,i)=trig(r,i)-(M(r,i)-m(r,i))*1.618;
    end   
end




  
end
    n=size(A,2);
    ng=n./2;
 
for k=1:ng:size(P,2)
  sP=P(:,k:k+ng-1);
  sMM=MedieMobili(:,k:k+ng-1);
  sf1=f1(:,k:k+ng-1);
  sf2=f2(:,k:k+ng-1);
  sf3=f3(:,k:k+ng-1);
  sf4=f4(:,k:k+ng-1);
  sf5=f5(:,k:k+ng-1);
  sf6=f6(:,k:k+ng-1);
  sf7=f7(:,k:k+ng-1);
  sliv1=liv1(:,k:k+ng-1);
  sliv2=liv2(:,k:k+ng-1);
  sliv3=liv2(:,k:k+ng-1);
  sA=A(:,k:k+ng-1);
  figure('NumberTitle', 'on', 'Name', 'PREZZI e MEDIE MOBILI');
  for ii=1:ng
      subplot(ng./5,5,ii);
                plot(D(end-gg:end,1), sP(end-gg:end,ii),'LineWidth',2);figure(gcf); hold all;
                plot(D(end-gg:end,1), sMM{1,ii}(end-gg:end,mB),'LineWidth',1);figure(gcf);hold all;
                plot(D(end-gg:end,1), sMM{1,ii}(end-gg:end,mL),'LineWidth',1,'DisplayName','Oscillatore{1,1}(end-gg:end,8)','YDataSource','Oscillatore{1,1}(end-gg:end,8)');figure(gcf);hold all;
                line([D(end-gg,1),D(end,1)],[sliv1(end,ii),sliv1(end,ii)],'Color','g', 'LineWidth', 1);
                line([D(end-gg,1),D(end,1)],[sliv2(end,ii),sliv2(end,ii)],'Color','g', 'LineWidth', 1);
                line([D(end-gg,1),D(end,1)],[sliv3(end,ii),sliv3(end,ii)],'Color','g', 'LineWidth', 1);
 
                line([D(end-gg,1),D(end,1)],[sf1(end,ii),sf1(end,ii)],'Color','r', 'LineWidth', 2 );
                line([D(end-gg,1),D(end,1)],[sf2(end,ii),sf2(end,ii)],'LineStyle','--', 'Color','b', 'LineWidth', 1 );
                line([D(end-gg,1),D(end,1)],[sf3(end,ii),sf3(end,ii)],'LineStyle','--','Color','b', 'LineWidth', 1 );
                line([D(end-gg,1),D(end,1)],[sf4(end,ii),sf4(end,ii)], 'Color','r', 'LineWidth', 2);
                line([D(end-gg,1),D(end,1)],[sf5(end,ii),sf5(end,ii)],'LineStyle','--','Color','b', 'LineWidth', 1 );
                line([D(end-gg,1),D(end,1)],[sf6(end,ii),sf6(end,ii)],'LineStyle','--','Color','b', 'LineWidth', 1 );
                line([D(end-gg,1),D(end,1)],[sf7(end,ii),sf7(end,ii)], 'Color','r','LineWidth', 2);


                datetick('x','ddmmyy','keepticks','keeplimits')
                ylim([min(sP(end-gg:end,ii))-abs(floor(min(sP(end-gg:end,ii))))*0.05 max(sP(end-gg:end,ii))+floor(max(sP(end-gg:end,ii)))*0.05])
                xlim('auto')
                grid on
                grid minor
                
                ylabel('Valori');
                xlabel('Tempo');
                h= legend('Medie Mobiili', 'Location', 'SW');
                title(sA(1,ii));
  end
end
end
