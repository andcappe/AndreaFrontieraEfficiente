function  [cic]=cicli(gg,slide,ciclo, A,D,P,j,le,la, tendenza, forza, battleplan,l,m,s,xs)
close all
rad=-1.5708;
rad(1,1)=rad(1,1)
rad(1,2)=rad(1,1)
rad(1,3)=rad(1,1)
rad(1,4)=rad(1,1)

cic=[l m s xs];
for i=2:ciclo
    rad(i,1)=rad(i-1,1)+(rad(1,1)/battleplan(1,1));
    rad(i,2)=rad(i-1,2)+(rad(1,1)/battleplan(1,2));
    rad(i,3)=rad(i-1,3)+(rad(1,1)/battleplan(1,3));
    rad(i,4)=rad(i-1,4)+(rad(1,1)/battleplan(1,4));
    
    cic(i,1)=sin(rad(i,1))*(-cic(1,1));
    cic(i,2)=sin(rad(i,2))*(-cic(1,2));
    cic(i,3)=sin(rad(i,3))*(-cic(1,3));
    cic(i,4)=sin(rad(i,4))*(-cic(1,4));
end


cic(:,5)=sum(cic,2)

int=(max(cic(1:243,5))-min(cic(1:243,5)))/486
cic(1,6)=cic(1,5)
for i=2:ciclo
    
 cic(i,6)= cic(i-1,6)+(int*tendenza*forza);
end
cic(:,7)=cic(:,6)+cic(:,5)
%
close all
figure (1)
plot(cic(:,7))

figure(2)
subplot(2,1,1)
data=P(:,j);
[lead,lag]=movavg(data,le,la,0)
[lead2,lag2]=movavg(data,le*2,la*4,0)
hold on
plot(D(end-gg:end,1),data(end-gg:end,1),'Color','b', 'LineWidth', 2)
plot(D(end-gg:end,1),lead(end-gg:end,1),'Color','r', 'LineWidth', 1)
plot(D(end-gg:end,1),lead2(end-gg:end,1),'Color','b', 'LineWidth', 1)
plot(D(end-gg:end,1),lag(end-gg:end,1),'Color','g', 'LineWidth', 1)
plot(D(end-gg:end,1),lag2(end-gg:end,1),'Color','c', 'LineWidth', 1)
datetick('x','ddmmyy','keepticks','keeplimits')
                    xlim('auto')
                    grid on
                    grid minor
                    ylabel('Valori')
                    xlabel('Tempo')
                    ylim auto
                    h= legend(A(1,j) , 'Location', 'NW');
       subplot(2,1,2)             

plot(D(end-gg:end,1),cic(1+slide:1+gg+slide,7),'Color','r', 'LineWidth', 1)

datetick('x','ddmmyy','keepticks','keeplimits')
                    xlim('auto')
                    grid on
                    grid minor
                    ylabel('Ciclo Battleplan')
                    xlabel('Tempo')
                    ylim('auto')
                    h= legend('Cicli battleplan' , 'Location', 'NW');
                     
%testPts = floor(0.8*length(data(:,1)));
%TitClose = data(1:testPts,1);
%TitCloseV = data(testPts+1:end,1);

end