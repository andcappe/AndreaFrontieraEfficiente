function [MedieMobili MedieCentrate Stocastico Oscillatore relstr,UI,rstdev,ROC] = indic(l,A,D,P)
close all

numT=size(P);


   
for x = 1:numT(2)
%x= 1;
     xC = P(:,x);
     xD= D(:,1);
     L=length(xC);
     
     for col=8:8:64
     r=col*2;
     
     for i=r:L 
        
        t1 = i-r+1;
        C = xC(t1:i);
        MM(i,col)=mean(C); 
        MC(i-(r/2),col) = MM(i,col); 
     end
     
     for i=L:L+(r/2) 
        t1 = i-r+1;
        C = xC(t1:L);
        MC(i-(r/2),col) = mean(C);
        
     end
     MedieMobili{x}=MM;
     MedieCentrate{x}=MC;
     end
     for i=1:32
    
     OS(:,i) = MC(:,i) - MC(:,i*2);
    
    end
    Oscillatore{x}=OS;

    
end

% Stocastico
for i=1:numT(2)
for x=l*4+1:numT(1)
    
    MIN(x,1)=min(P(x-l*1:x,i));
    MIN(x,2)=min(P(x-l*2:x,i));
    MIN(x,3)=min(P(x-l*3:x,i));
    MIN(x,4)=min(P(x-l*4:x,i));
    
    MAX(x,1)=max(P(x-l*1:x,i));
    MAX(x,2)=max(P(x-l*2:x,i));
    MAX(x,3)=max(P(x-l*3:x,i));
    MAX(x,4)=max(P(x-l*4:x,i));
    
    CLOSE(x,1)=(P(x,i));
    CLOSE(x,2)=(P(x,i));
    CLOSE(x,3)=(P(x,i));
    CLOSE(x,4)=(P(x,i));
    
    
    STOC(x,1)=((CLOSE(x,1)-MIN(x,1)))/((MAX(x,1)-MIN(x,1)));
    STOC(x,2)=(CLOSE(x,2)-MIN(x,2))/(MAX(x,2)-MIN(x,2));
    STOC(x,3)=(CLOSE(x,3)-MIN(x,3))/(MAX(x,3)-MIN(x,3));
    STOC(x,4)=(CLOSE(x,4)-MIN(x,4))/(MAX(x,4)-MIN(x,4));
    
    STO(x,1)=mean(STOC(x-3:x,1));
    STO(x,2)=mean(STOC(x-3:x,2));
    STO(x,3)=mean(STOC(x-3:x,3));
    STO(x,4)=mean(STOC(x-3:x,4));
    
     
end
Stocastico{i} = STO;
end
% Calcolo RSI
l=7; % RSI multipli moltiplicatore

for i=1:numT(2)
    
RS(:,1)= rsindex(P(:,i),l*1);
RS(:,2)= rsindex(P(:,i),l*2);
RS(:,3)= rsindex(P(:,i),l*3);
RS(:,4)= rsindex(P(:,i),l*4);
relstr{i}=RS;
end
   % Calcolo Ulcer Index
   
   for i=1:numT(2)
       
        for x=2:10
           
        for j=x*5+1:numT(1)
          
   PDD(j,x-1)=((P(j,i)-max(P(j-x*5:j,i)))/max(P(j-x*5:j,i)))*100;
   SA(j,x-1) = (sum(PDD(j-x*5:j,x-1))/x*5)^2 ;
   ui(j,x-1) = sqrt(SA(j,x-1));
   
        end
        end
      
       
        UI{1,i}=ui;
      
       
   end
   %Calcolo rstdev
   for i=1:numT(2)
       
        for x=2:10
           
        for j=105:numT(1)
          
   rdev(j,x-1)=std(P(j-x*10:j,i));
   
   
        end
        end
      
       
        rstdev{1,i}=rdev;
      
% Calcolo ROC
l=9; % Roc giorni
for i=1:numT(2)
    for j=4*l+1:numT(1)
    
roc(j,1)= (P(j,i)/P(j-l*1,i)-1)*100;
roc(j,2)= (P(j,i)/P(j-l*2,i)-1)*100;
roc(j,3)= (P(j,i)/P(j-l*3,i)-1)*100;
roc(j,4)= (P(j,i)/P(j-l*4,i)-1)*100;
ROC{1,i}=roc;
    end
end
       
   end
  end  
