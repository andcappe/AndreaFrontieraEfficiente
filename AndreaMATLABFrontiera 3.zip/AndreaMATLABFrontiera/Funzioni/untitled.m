S=P(:,2)./P(:,3)
P(:,2)=S
datetime(D(:,1))