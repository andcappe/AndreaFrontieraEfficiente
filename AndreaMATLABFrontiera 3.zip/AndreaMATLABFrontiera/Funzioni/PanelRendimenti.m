function [rfP] = PanelRendimenti(gg,r,A,D,P)

close all

n=size(A,2);
    ng=n./2;
nP=size(P);

fP=P(nP(1)-gg:nP(1),:);
fD=D(nP(1)-gg:nP(1),1);

[fPr fPc]=size(fP);

for  i=1:fPr
    for j=1:fPc
        rfP(i,j)=   (fP(i,j)-fP(1,j))./fP(1,j);
    end
    
end
if r==100
rfP=100+100*rfP;
else
rfP=rfP;


end

for k=1:ng:size(rfP,2);
  srfP=rfP(:,k:k+ng-1);
  
  srfA=A(:,k:k+ng-1);
  figure('NumberTitle', 'on', 'Name', 'RENDIMENTI');
  for ii=1:ng
      subplot(ng./5,5,ii);
      
                
                
				plot(D(end-gg:end,1), srfP(1:end,ii),'LineWidth',2);
    
                datetick('x','ddmmyy','keepticks','keeplimits')
                ylim([min(srfP(end-gg:end,ii))-abs(floor(min(srfP(end-gg:end,ii))))*0.05 max(srfP(end-gg:end,ii))+floor(max(srfP(end-gg:end,ii)))*0.05])
                xlim('auto')
                grid on
                grid minor
                
                ylabel('Valori');
                xlabel('Tempo');
                h= legend('Rendimenti' , 'Location', 'SW');
                title(srfA(1,ii));
				
  end
end
			
    
end

