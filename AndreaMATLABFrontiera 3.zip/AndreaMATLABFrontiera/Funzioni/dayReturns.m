function [fD, rfP]=dayReturns(giorni,r,A,D,P)

        
close all



nP=size(P);

fP=P(nP(1)-giorni:nP(1),:);
fD=D(nP(1)-giorni:nP(1),1);

[fPr fPc]=size(fP);

for  i=1:fPr
    for j=1:fPc
        rfP(i,j)=   (fP(i,j)-fP(1,j))./fP(1,j);
    end
    
end
if r==1
rfP=100+100*rfP;
else
rfP=rfP;
end

figure(1);

plot(fD(fPr-giorni:fPr,1),rfP(fPr-giorni:fPr,:));

    datetick('x', 'ddmmyy');
    grid on;
    title('Rendimento Asset Class') ;
    ylabel('Valori');
    xlabel('Tempo');
    legend(A, 'Location', 'northwest');    
    
    filename='rendimentoAssetClass.mat';
    save(filename);

   
end
