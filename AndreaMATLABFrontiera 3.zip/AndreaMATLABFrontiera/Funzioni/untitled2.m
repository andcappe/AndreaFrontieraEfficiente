%%
x = T.Musa; % Prima variabile
y = T.Inflazione; % Seconda variabile
format long
b1 = x\y

%Scatter Plot
yReg = b1*x;
scatter(x,y)
hold on
plot(x,yReg)
xlabel('Variabile indipendente X')
ylabel('Variabile dipendente Y')
title('Linear Regression Relation Between Prima e seconda variabile')
grid on