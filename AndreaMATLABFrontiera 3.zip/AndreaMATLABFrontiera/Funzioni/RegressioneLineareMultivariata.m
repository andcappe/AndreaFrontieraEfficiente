%% Regressione
%  Il modello di regressione lineare:
%  y=?0+?1x+?
T = dataset2table( Dataset )

%% Carico i dati dal foglio di calcolo di Excel 
% Si prepara il file ordinando in colonne le variabili da analizzare 

clc; 
clear all; 

file = 'USdata.xlsx'; 
T= readtable(file)
%formatIn = 'gg-mmm-yyyy';
T.Anno=datenum(T.Anno)   %x2mdate(T.Anno) ; ,formatIn

%% Nomi variabili analizzate
VarNam = T.Properties.VariableNames % Serve solo per richiamare i nomi delle variabili
%%

plotyy(T.Anno,T.Inflazione, T.Anno,T.Disoccupazione) % Posso mettere a confronto le varie variabili cambiando dopo il termine T. la variabile che voglio analizzare.

datetick('x','yyyy')
grid on
xlabel('Anni')
ylabel('Variazioni percentuali')
h= legend({'Inflazione', 'Disoccupazione'}  , 'Location', 'SW')
title('Grafico Variabile')



%% Modelli
startime=230; % Indico i trimestri da analizzare
endtime=0; % Indico se voglio analizzare i trimestri indicati sopra da n trimestri indietro nel tempo rispetto ad oggi.
modelspec = 'Inflazione ~ CrudeOil ' % Questa riga serve a modificare 


Dati=size(T,1)-endtime
D=T(Dati-startime:Dati,:)

% Modelli di esempio togliere il carattere % e metterlo sopra per
% analizzare i successivi modelli di esempio 
% modelspec = 'TY ~ Inflazione + Musa + Disoccupazione + GDP + MV + CrudeOil  ' 
% modelspec = 'Inflazione ~      Musa    '
% modelspec = 'Inflazione ~ Musa + Disoccupazione + GDP + MV+ CrudeOil + TY' 
% modelspec = 'Inflazione ~ TY + Musa + Disoccupazione + GDP + MV + CrudeOil  '
% modelspec = 'TY ~ Inflazione  + Disoccupazione + GDP  + CrudeOil' % Questa riga serve a modificare 

mdl = fitlm(D,modelspec) % ***,'RobustOpts','on'*** se si vogliono dati robusti all'eteroschedasticit? indicare il valore tra gli asterischi. 
plotResiduals(mdl)
%% Plotting dei residui


 
Res = table2array(mdl.Residuals);
 boxplot(Res) 
 
 plotResiduals(mdl,'lagged')
 
 plotResiduals(mdl,'symmetry')
 
 plotResiduals(mdl,'fitted')
%% Miglioriamo il modello
mdl1 = step(mdl,'NSteps',10)
plotResiduals(mdl)

%% Test Normalit? Kolmogorov mdl


test1 = mdl.Residuals.Raw;
x = (test1-0)/mdl.RMSE;
h = kstest(x)
 
% Grafico
cdfplot(x)
hold on
x_values = linspace(min(x),max(x));
plot(x_values,normcdf(x_values,0,1),'r-')
legend('Empirical CDF','Standard Normal CDF','Location','best')
%% Test Normalit? Kolmogorov mdl1


test1 = mdl1.Residuals.Standardized;
x = (test1-mean(mdl1.Residuals.Standardized))/std(mdl1.Residuals.Standardized);
h = kstest(x)
 
% Grafico
cdfplot(x)
hold on
x_values = linspace(min(x),max(x));
plot(x_values,normcdf(x_values,0,1),'r-')
legend('Empirical CDF','Standard Normal CDF','Location','best')

%% Plot della regressione e dei modelli stimati
plot(D.Anno,D.Disoccupazione) % indicare dopo D. la variabile da plottare.
hold on;

ypred = predict(mdl);
ypred2= predict(mdl1)
 
hold on;
plot(D.Anno,ypred)
plot(D.Anno,ypred2)
datetick('x','ddmmyy','keepticks','keeplimits')
                    xlim('auto')
                    grid on
                    grid minor
                    ylabel('Valori')
                    xlabel('Tempo')
                    h= legend({'Regressione', 'Modello' 'Ottimizzazione'}  , 'Location', 'SW');
                    title('PREVISIONE') 
                    
                   
%% Test di Eteroschedasticit?

[T,P,df] = BPtest(mdl)

%%
[AX, H1, H2]=plotyy(n', H, n',mdl.Residuals.Raw)
%set(AX(1),'Ylim',[min(H) max(H)])
%set(AX(2),'Ylim',[min(mdl.Residuals.Raw) max(mdl.Residuals.Raw)])
axis auto
