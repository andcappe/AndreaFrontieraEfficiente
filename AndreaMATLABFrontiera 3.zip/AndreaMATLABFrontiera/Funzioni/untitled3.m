subplot(2,1,2)
plot(D(end-gg:end,1),cic(1:end+gg,7),'Color','r', 'LineWidth', 1)
ylim([-20 20])
datetick('x','ddmmyy','keepticks','keeplimits')
                    xlim('auto')
                    grid on
                    grid minor
                    ylabel('Valori')
                    xlabel('Tempo')
                    ylim auto
                    h= legend(A(1,j) , 'Location', 'SW');
                    title(A(1,j)) 
testPts = floor(0.8*length(data(:,1)));
TitClose = data(1:testPts,1);
TitCloseV = data(testPts+1:end,1);