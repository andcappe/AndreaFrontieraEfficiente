clear all; clc;
gg=250; %giorni
startdate='1-Jan-2018';
file='Tit.xlsx'; %'titoli.xlsx'
freq='d';
benchmark='aznax';


function [A,D,P] = sca(varargin)

switch nargin
            case 0
            %disp ('0 Inputs' )
            gg=252;
            startdate='1-Jan-2018';
            file = 'Tit.xlsx';
            freq = 'd';
            benchmark = 'AZNAX';


        case 1
            %disp ('1 Input')
            gg=varargin{1};
            startdate='1-Jan-2018';
            file = 'tit.xlsx';
            freq = 'd';
            benchmark = 'AZNAX';


        case 2
            %disp ('2 Inputs')
            gg=varargin{1};
            startdate=varargin{2};
            file = 'tit.xlsx';
            freq = 'd';
            benchmark = 'AZNAX';


        case 3
            %disp ('3 Inputs')
            gg=varargin{1};
            startdate=varargin{2};
            file = varargin{3};
            freq = 'd';
            benchmark = 'AZNAX';

        case 4
            %disp ('4 Inputs')
            gg=varargin{1};
            startdate=varargin{2};
            file = varargin{3};
            freq = varargin{4};
            benchmark = 'AZNAX'; 
         case 5
            %disp ('4 Inputs')
            gg=varargin{1};
            startdate=varargin{2};
            file = varargin{3};
            freq = varargin{4};
            benchmark = varargin{5};
        otherwise
            error ('Troppi Inputs, questa funzione ne accetta 5. gg, startdate, file, freq, benchmark') 


    T= readtable(file); % Legge il file con gli ISIN
    T=(table2cell(T))'; % Mette sulle righe gli ISIN

    A = T(1,:); % Prende la riga degli ISIN
    %DES = T(2,:);
    S=size(A,2); % Misura la dimensione della matrice degli ISIN
    A(1,S+1)=cellstr(upper(benchmark)); % Aggiunge il BENCHMARK agli ISIN
    DES(1,S+1)=cellstr(upper(benchmark)); % Crea le descrizioni degli ISIN

 [rA,cA]= size(A);

for i=1:cA
            stock = getMarketDataViaYahoo(A{1,i},startdate); % Scarica i dati uno ad uno per ISIN e crea una tabella

                if isnumeric(stock.Close)==true % Verifica i valori se sono numerici della colonna Close

                Desc = DES{1,i}; % Scompone i dati della tabella
                Date = stock.Date
                Open = stock.Open;
                High = stock.High;
                Low = stock.Low;
                Close = stock.Close;
                Volume = stock.Volume;

                StockData_TimeTable = timetable(Date,Open,High,Low,Close,Volume); % Timetable per riempire i dati mancanti.
                %StockData_TimeTable = retime(StockData_TimeTable,'daily','previous');
                    if any(any(ismissing(StockData_TimeTable)))==true
                        StockData_TimeTable = fillmissing(StockData_TimeTable,'nearest'); %Inserisce i dati mancanti prendendo il pi? vicino
                    end
                %%TT=timetable2table(StockData_TimeTable)
                elseif isnumeric(stock.Close)==false
                        stock.Close=str2double(stock.Close); % Se il close non risulta numerico converte la stringa in valore double.

                Desc = A{1,i};
                Date = stock.Date;
                Open = stock.Open;
                High = stock.High;
                Low = stock.Low;
                Close = stock.Close;
                Volume = stock.Volume;

                StockData_TimeTable = timetable(Date,Open,High,Low,Close,Volume);
                %StockData_TimeTable = retime(StockData_TimeTable,'daily','previous');
                    if any(any(ismissing(StockData_TimeTable)))==true
                        StockData_TimeTable = fillmissing(StockData_TimeTable,'nearest');
                    end

                end
           
                P(:,i) = StockData_TimeTable.Close(end-gg:end,1);
                D(:,i) = floor(datenum(StockData_TimeTable.Date(end-gg:end,1)));



                clear stock ;
                clear ans;

            end


end
